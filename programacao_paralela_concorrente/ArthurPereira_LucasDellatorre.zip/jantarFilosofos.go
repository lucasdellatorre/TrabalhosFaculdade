// Lucas Dellatorre de Freitas / Arthur Pereira Viegas

package main

import (
	"fmt"
	"strconv"
)

const (
	PHILOSOPHERS = 5
	FORKS        = 5
	NEWFORKS     = 15
)

func philosopher(id int, first_fork chan struct{}, second_fork chan struct{}) {
	for {
		fmt.Println(strconv.Itoa(id) + " Filosofo Destro = senta")
		<-first_fork // pega
		fmt.Println(strconv.Itoa(id) + " Filosofo Destro = pegou direita")
		<-second_fork
		fmt.Println(strconv.Itoa(id) + " Filosofo Destro = come")
		first_fork <- struct{}{} // devolve
		second_fork <- struct{}{}
		fmt.Println(strconv.Itoa(id) + " Filosofo Destro = levanta e pensa")
	}
}

// a) evitando formação de ciclo com quebra de simetria dos processos (filosofo canhoto)
//
//	 Solução
//		|
//		|
//		V
func philosopherA(id int, first_fork chan struct{}, second_fork chan struct{}) {
	for {
		if id == 4 {
			fmt.Println(strconv.Itoa(id) + " senta")
			<-second_fork // pega
			fmt.Println(strconv.Itoa(id) + " pegou direita")
			<-first_fork
			fmt.Println(strconv.Itoa(id) + " come")
			first_fork <- struct{}{} // devolve
			second_fork <- struct{}{}
			fmt.Println(strconv.Itoa(id) + " levanta e pensa")
		} else {
			fmt.Println(strconv.Itoa(id) + " senta")
			<-first_fork // pega
			fmt.Println(strconv.Itoa(id) + " pegou direita")
			<-second_fork
			fmt.Println(strconv.Itoa(id) + " come")
			first_fork <- struct{}{} // devolve
			second_fork <- struct{}{}
			fmt.Println(strconv.Itoa(id) + " levanta e pensa")
		}
	}
}

// b) evitando hold and wait fazendo com que o filosofo largue o primeiro garfo se o segundo estiver ocupado
//
//	 Solução
//		|
//		|
//		V
func philosopherB(id int, first_fork chan struct{}, second_fork chan struct{}) {
	for {
		fmt.Println(strconv.Itoa(id) + " senta")

		<-first_fork // pega
		fmt.Println(strconv.Itoa(id) + " pegou direita")

		select {
		case <-second_fork:
			fmt.Println(strconv.Itoa(id) + " pegou esquerda")
			fmt.Println(strconv.Itoa(id) + " come")
			first_fork <- struct{}{} // devolve
			second_fork <- struct{}{}
			fmt.Println(strconv.Itoa(id) + " levanta e pensa")

		default: //Solta o primeiro canal caso não consiga ler o segundo
			first_fork <- struct{}{}
			fmt.Println(strconv.Itoa(id) + " tudo cheio aq n comi nada")
		}
	}
}

// c) evitando hold and wait sendo a ação de pegar os dois garfos (ou nenhum) atômica
//
//	|
//	|
//	V
func philosopherC(id int, first_fork chan struct{}, second_fork chan struct{}) {
	for {
		fmt.Println(strconv.Itoa(id) + " senta")

		if len(first_fork) == 1 && len(second_fork) == 1 {
			fmt.Println(strconv.Itoa(id) + " peguei os dois garfos")
			<-first_fork
			<-second_fork
			fmt.Println(strconv.Itoa(id) + " comi")
			first_fork <- struct{}{} // devolve
			second_fork <- struct{}{}
			fmt.Println(strconv.Itoa(id) + " levanta e pensa")
		} else {
			fmt.Println(strconv.Itoa(id) + " não consegui pegar os dois garfos, não comi nada")
		}

	}
}

// D) Adicionando garfos
//
//	|
//	|
//	V
func philosopherD(id int, first_fork chan struct{}, second_fork chan struct{}, third_fork chan struct{}) {
	for {
		fmt.Println(strconv.Itoa(id) + " senta")

		select {
		case <-first_fork:
			fmt.Println(strconv.Itoa(id) + " pegou esquerda")
			select {
			case <-second_fork:
				fmt.Println(strconv.Itoa(id) + " pegou direita")
				fmt.Println(strconv.Itoa(id) + " come")
				first_fork <- struct{}{} // devolve
				second_fork <- struct{}{}
				fmt.Println(strconv.Itoa(id) + " levanta e pensa")

			default:
				fmt.Println(strconv.Itoa(id) + " pegou esquerda")
				<-third_fork
				fmt.Println(strconv.Itoa(id) + " pegou o garfo novo")
				fmt.Println(strconv.Itoa(id) + " come")
				first_fork <- struct{}{} // devolve
				third_fork <- struct{}{}
				fmt.Println(strconv.Itoa(id) + " levanta e pensa")
			}
		default:
			select {
			case <-second_fork:
				fmt.Println(strconv.Itoa(id) + " pegou direita")
				<-third_fork
				fmt.Println(strconv.Itoa(id) + " pegou o garfo novo")
				second_fork <- struct{}{} // devolve
				third_fork <- struct{}{}
				fmt.Println(strconv.Itoa(id) + " levanta e pensa")

			default:
			}

		}
	}
}

func main() {
	var fork_channels [FORKS]chan struct{}
	for i := 0; i < FORKS; i++ {
		fork_channels[i] = make(chan struct{}, 1)
		fork_channels[i] <- struct{}{} // no inicio garfo esta livre
	}

	var fork_channels_plus [NEWFORKS]chan struct{} //SOLUCAO ADICIONAR GARFOS
	for i := 0; i < NEWFORKS; i++ {
		fork_channels_plus[i] = make(chan struct{}, 1)
		fork_channels_plus[i] <- struct{}{} // no inicio garfo esta livre
	}

	for i := 0; i < (PHILOSOPHERS); i++ {
		fmt.Println("Filosofo " + strconv.Itoa(i))
		//go philosopher(i, fork_channels[i], fork_channels[(i+1)%PHILOSOPHERS])       					//ROTINA NORMAL

		// if i == (PHILOSOPHERS - 1) { 																//SOLUCAO CANHOTO
		// 	go philosopherA(i, fork_channels[i], fork_channels[(i+1)%PHILOSOPHERS])
		// }else{
		// 	go philosopher(i, fork_channels[i], fork_channels[(i+1)%PHILOSOPHERS])
		// }

		//go philosopherB(i, fork_channels[i], fork_channels[(i+1)%PHILOSOPHERS])						//SOLUCAO SE NAO PEGAR SOLTA

		//go philosopherC(i, fork_channels[i], fork_channels[(i+1)%PHILOSOPHERS])						//SOLUCAO ATOMICA, OU PEGA OS DOIS OU NENHUM

		//go philosopherD(i, fork_channels_plus[i], fork_channels_plus[(i+1)%PHILOSOPHERS], fork_channels_plus[(i+2)%PHILOSOPHERS]) //SOLUCAO ADICIONANDO GARFOS

	}
	var blq chan struct{} = make(chan struct{})
	<-blq
}
