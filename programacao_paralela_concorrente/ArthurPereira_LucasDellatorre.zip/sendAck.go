//  Um sistema tem um gerador de dados que solicita a um processo Fonte enviar dados
//  para um processo Destino.
//  A cada dado recebido, o Destino manda uma confirmação para a Fonte.
//  Note que isto é uma modelagem de um sistema onde a confirmacao seria importante.
//  Com canais não existe necessidade de confirmacao de recepcao pois nenhum dado é perdido.
//  Rode este sistema e veja se algum problema ocorre.   Corrija o problema.

// Lucas Dellatorre de Freitas / Arthur Pereira Viegas

package main

import (
	"fmt"
  "strconv"
)

const (
	N = 100
	T = 5
)

var solicitaEnvio = make(chan int, T)
var envia = make(chan int, T)

func Gerador(fin chan bool) {
	for i := 1; i < N; i++ {
		fmt.Println("Gerou " + strconv.Itoa(i))
    solicitaEnvio <- i
	}
}
func Fonte(fin chan bool) {
	for i := 1; i < N; i++ {
		x := <-solicitaEnvio
		fmt.Println("envio de " + strconv.Itoa(x))
    	envia <- x
	}
}

func Destino(fin chan bool) {
	for i := 1; i < N; i++ {
		fmt.Println("Jogou fora " + strconv.Itoa(<-envia))
    if (i == (N - 1)) { fin <- true }
	}
}

func main() {
	fin := make(chan bool, 1)
  go Gerador(fin)
	go Fonte(fin)
	go Destino(fin)
	<- fin
}
